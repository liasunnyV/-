# 证件照api，证件照排版 demo

**python版本**

### make.py   # 证件照制作
### print.py  # 证件照排版
