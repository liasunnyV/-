from PIL import Image
import os

def print_main():
    id_photo = Image.open(os.getcwd() + '/test.jpeg')  # 一寸证件照
    print_bg = Image.open(os.getcwd() + '/295-413.png')  # 获取排版背景图

    print_bg.paste(id_photo, (120, 180))
    print_bg.paste(id_photo, (435, 180))
    print_bg.paste(id_photo, (750, 180))
    print_bg.paste(id_photo, (1065, 180))
    print_bg.paste(id_photo, (1380, 180))
    print_bg.paste(id_photo, (120, 613))
    print_bg.paste(id_photo, (435, 613))
    print_bg.paste(id_photo, (750, 613))
    print_bg.paste(id_photo, (1065, 613))
    print_bg.paste(id_photo, (1380, 613))

    path = os.getcwd() + "/res-print.jpeg"
    print_bg.save(path)  # 保存排版照
    print_bg.show()  # 显示

if __name__ == '__main__':
    print_main()