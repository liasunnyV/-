# 证件照api，证件照排版 demo

**php版本**

### make.php   # 证件照制作
### print.php  # 证件照排版
